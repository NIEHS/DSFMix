#include <Rinternals.h>
#include <R_ext/Rdynload.h>

extern "C" {

    void
    R_init_spade(DllInfo *info) {
	static const R_CallMethodDef _CallFun[] = {
	    {NULL}
	};

    }

} // extern
